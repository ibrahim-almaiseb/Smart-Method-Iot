

const char get_js[]  = R"=====(
      function sendData ( url,gotResp ) {  
                            var xhttp = new XMLHttpRequest();
                            xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {                        
                            gotResp( this.responseText );                           
                            }
                            };
                            xhttp.open('GET', url , true);
                            xhttp.send();
      }
      )=====";


const char html_script[]  = R"=====(
                           <!doctype html>
 <head>
    <style>
      /* CSS comes here */
      body {
          font-family: arial;
      }
      button {
          padding:10px;
          background-color:#6a67ce;
          color: #FFFFFF;
          border: 0px;
          cursor:pointer;
          border-radius: 5px;
      }
      #output {
          background-color:#F9F9F9;
          padding:10px;
          width: 100%;
          margin-top:20px;
          line-height:30px;
      }
      .hide {
          display:none;
      }
      .show {
          display:block;
      }
    </style>
    <title>ROBOT CONTROL</title>
     <meta name='viewport' content='width=device-width, initial-scale=1.0' >
          <script src='getTrigger' >   </script>   
  </head>
  <body>
  <center>
    <h2>ROBOT CONTROL</h2>
        <p><button type="button" onclick="runSpeechRecognition()">Speak Now</button> &nbsp; <span id="action"></span></p>
        <div id="output" ></div>
     </center> 
    <script>
    var speakNow = 0;

    setInterval(joo,500);

    function joo() {
   if ( speakNow == 1 ) {
    speakNow = 0;
    runSpeechRecognition();
   }  
    } // end
 
        function runSpeechRecognition() {
            // get output div reference
            var output = document.getElementById("output");
           // output.innerHTML = '';
            // get action element reference
            var action = document.getElementById("action");

                // new speech recognition object
                var SpeechRecognition = SpeechRecognition || webkitSpeechRecognition;

                // window.SpeechRecognition = window.SpeechRecognition
               //         || window.webkitSpeechRecognition;
                
                var recognition = new SpeechRecognition();
  
            
                // This runs when the speech recognition service starts
                recognition.onstart = function() {
                    action.innerHTML = "<br><br><small>listening....</small>";
                };
                
                recognition.onspeechend = function() {
                  //  action.innerHTML = "<small>stopped listening, hope you are done...</small>";
                  //  recognition.stop();
                   sendingBack("end","end");
                }
              
                // This runs when the speech recognition service returns result
                recognition.onresult = function(event) {
                    var transcript = event.results[0][0].transcript;
                    var confidence = event.results[0][0].confidence;
                    output.innerHTML = "<b>Text:</b> " + transcript + "<br/> <b>Confidence:</b> " + confidence*100+"%";
                  //  output.classList.remove("hide");
                   // recognition.stop();
                    sendingBack(transcript,confidence);
                    speakNow = 1;
                };
              
                 // start recognition
                 recognition.start();
         
          }  // end function

          function sendingBack(transcript,confidence) {
          sendData('send_info?aa='+transcript+'&bb='+confidence,function(mm) {
            // alert(mm);
            }); 
          }  // end
    </script>
  </body>
</html>
    )=====";
