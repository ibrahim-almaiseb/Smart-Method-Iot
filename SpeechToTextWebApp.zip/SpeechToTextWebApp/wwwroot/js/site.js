﻿var audioSetupIntervalId;
var startRecordingBtn = document.querySelector("#start-recording-btn");
var stopRecordingBtn = document.querySelector("#stop-recording-btn");
var recordingStatusElem = document.querySelector("#recording-status");
var textTranscriptElem = document.querySelector("#text-transcript");
var mediaRecorder;
/**
 * Used to store blobs of audio recording content.
 */
var chunks;

window.onload = () => {
    setUpStream();

    // Create a media stream when recording is supported.
    audioSetupIntervalId = setInterval(setUpStream, 2000);
};

/**
 * Checks if the browser supports recording from a media device and if
 * the user has given permission for recording, then creates a media stream.
 */
function setUpStream() {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia(
            {
                audio: true
            }).then(function (stream) {
                startRecordingBtn.disabled = false;

                setUpMediaRecorder(stream);

                clearInterval(audioSetupIntervalId);

                recordingStatusElem.innerHTML = "Not started recording";
            }).catch(function (err) {
                startRecordingBtn.disabled = true;

                recordingStatusElem.innerHTML = `<span class="text-danger">Please enable audio recordings from your browser settings.</span>`;
            });
    } else {
        startRecordingBtn.disabled = true;

        recordingStatusElem.innerHTML = `<span class="text-danger">Please check that your browser supports audio recordings.</span>`;
    }
}

/**
 * Sets up the MediaRecorder objcet used to record the user's voice.
 */
function setUpMediaRecorder(stream) {
    mediaRecorder = new MediaRecorder(stream);

    mediaRecorder.ondataavailable = function (e) {
        chunks.push(e.data);
    }

    mediaRecorder.onerror = function (e) {
        recordingStatusElem.innerHTML = "Recording stopped";
        alert(`An error has occurred while recording audio. Please check your browser settings`);
    };
}

/**
 * Listens to the click event for the button to start recording audio.
 */
startRecordingBtn.addEventListener("click", () => {
    startRecordingBtn.disabled = false;
    startRecordingBtn.classList.add("d-none");
    stopRecordingBtn.classList.remove("d-none");

    recordingStatusElem.innerHTML = "Recording";
    textTranscriptElem.innerHTML = "";

    chunks = [];

    if (mediaRecorder.state === "recording") {
        return;
    }

    try {
        mediaRecorder.start(100); // Process audio data every 100ms.
    } catch (error) {
        alert("An error has occurred when trying to start recording audio.");

        stopRecordingBtn.classList.add("d-none");
        startRecordingBtn.classList.remove("d-none");

        recordingStatusElem.innerHTML = "Not recording";

        setUpStream();

        audioSetupIntervalId = setInterval(setUpStream, 2000);
    }
});

/**
 * Listens to the click event for the button to stop the audio recording.
 */
stopRecordingBtn.addEventListener("click", () => {
    stopAndProcessRecording();
});

/**
 * Process the user's audio recording and then send it to the server to perform speech synthesis using the Google Speech-to-Text API.
 */
function stopAndProcessRecording() {
    startRecordingBtn.classList.remove("d-none");
    stopRecordingBtn.classList.add("d-none");

    recordingStatusElem.innerHTML = "Stopped listening";

    if (mediaRecorder.state !== "inactive") {
        mediaRecorder.stop();
    }

    blob = new Blob(chunks, { "type": "audio/mp3" });

    audioURL = URL.createObjectURL(blob);

    let formData = new FormData();
    formData.append("audio", blob);

    textTranscriptElem.innerHTML = "(Processing audio recording)";

    fetch("/Audio/ProcessAudioRecording", { method: "POST", body: formData })
        .then(function (response) {
            if (response.ok) {
                response.json().then(json => textTranscriptElem.innerHTML = json.responseText);
            }
            else {
                response.json().then(json => {
                    alert(json.error);
                    textTranscriptElem.innerHTML = "";
                }).catch(function () {
                    alert("An error has occurred when trying to process your audio recording.");

                    textTranscriptElem.innerHTML = "";
                });
            }
        }).catch(function (err) {
            alert("An error has occurred.");

            startRecordingBtn.disabled = true;

            textTranscriptElem.innerHTML = "";
        });
}