﻿using Google.Cloud.Speech.V1;
using Microsoft.AspNetCore.Mvc;

namespace SpeechToTextWebApp.Controllers
{
    public class AudioController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Gets a text transcription for a user's audio recording using the Google Speech-to-Text API
        /// </summary>
        /// <param name="form">The form which includes the audio data.</param>
        /// <returns>A <see cref="JsonResult"/> object with the result, or an error if an exception occurred.</returns>
        [HttpPost]
        public async Task<JsonResult> ProcessAudioRecording(IFormCollection form)
        {
            try
            {
                var audioData = form.Files["audio"];

                if (audioData == null || audioData.Length == 0)
                {
                    return new JsonResult(new { error = "Please note that your audio recording is invalid." })
                    {
                        StatusCode = 400
                    };
                }

                if (Environment.GetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS") == null)
                {
                    Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", @"<path-to-service-key>");
                }

                using MemoryStream audioMs = new MemoryStream();

                await audioData.CopyToAsync(audioMs);
                audioMs.Position = 0;

                RecognitionAudio audioRecoginition = RecognitionAudio.FromStream(audioMs);

                SpeechClient client = SpeechClient.Create();

                RecognitionConfig config = new RecognitionConfig
                {
                    LanguageCode = LanguageCodes.English.UnitedKingdom
                };

                RecognizeResponse response = client.Recognize(config, audioRecoginition);

                return Json(new { responseText = response.Results.FirstOrDefault()?.Alternatives?.FirstOrDefault()?.Transcript ?? "(No result is available)" });
            }
            catch (Exception)
            {
                return new JsonResult(new { error = "An error has occurred while processing your audio recording." })
                {
                    StatusCode = 500
                };
            }
        }
    }
}